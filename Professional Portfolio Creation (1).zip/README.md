
  # Professional Portfolio Creation

  This is a code bundle for Professional Portfolio Creation. The original project is available at https://www.figma.com/design/p410qpvIRa1SfpZGJ6giVj/Professional-Portfolio-Creation.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  